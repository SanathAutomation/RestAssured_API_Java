# RestAssuredAPITestingFramework
Rest Assured API Testing Framework Tutorial

# Rest Assured API Testing Full Courses Playlist Link - 

# Part-01 - https://www.youtube.com/watch?v=o9KJhGHl49M&list=PLUeDIlio4THGL7lQXQwxsV9re_i0U2b0Q&index=3

# Part-02 - https://www.youtube.com/watch?v=kay86__5eTg&list=PLUeDIlio4THGL7lQXQwxsV9re_i0U2b0Q&index=4


# Postman API Testing Full Courses Playlist Link - https://www.youtube.com/watch?v=QKBa8lt5Wfo&list=PLUeDIlio4THGaSQ_s5WFc2Mo7Ikne2kA5&index=1
