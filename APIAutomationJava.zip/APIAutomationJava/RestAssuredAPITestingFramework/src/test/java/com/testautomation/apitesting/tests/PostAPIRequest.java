package com.testautomation.apitesting.tests;

import io.restassured.path.json.JsonPath;
import io.restassured.response.ResponseBody;
import io.restassured.specification.RequestSpecification;
import org.hamcrest.Matcher;
import org.hamcrest.Matchers;
import org.testng.Assert;
import org.testng.annotations.Test;

import com.testautomation.apitesting.utils.BaseTest;

import io.restassured.RestAssured;
import io.restassured.http.ContentType;
import io.restassured.response.Response;
import net.minidev.json.JSONObject;

public class PostAPIRequest extends BaseTest{

	@Test(priority = 1)
	public void createTCIQDatabases(){
		String createtciqDbRequestBody = "{\n" +
				"    \"id\": \"test_sanath\",\n" +
				"    \"organization_id\": \"spirent\",\n" +
				"    \"name\": \"unique_name\",\n" +
				"    \"datastore\": {\n" +
				"        \"id\": \"default\",\n" +
				"        \"provider\": \"postgres\"\n" +
				"    }\n" +
				"}" ;

		Response response = RestAssured.given()
				.contentType(ContentType.JSON)
				.body(createtciqDbRequestBody)
				.baseUri("http://10.109.222.123/tciq/databases")
				//.log().all()
				.when()
				.post()
				.then()
				.assertThat()
				//.log().ifValidationFails()
				.statusCode(201)
						.body("name", Matchers.equalTo("unique_name"))
				        .body("datastore.id", Matchers.equalTo("default"))
				        .body("datastore.provider", Matchers.equalTo("postgres"))
				.extract()
				.response() ;
		//responsetciqdb.body()
		ResponseBody responseBody = response.getBody();
		System.out.println("Response body for TCIQdb is " + responseBody.asString());

		//get values from response
		JsonPath JsonPathEvaluate = response.jsonPath();
		String dbid = JsonPathEvaluate.get("id") ;
		System.out.println("First Db id is " +dbid);



	}


	@Test(priority = 0)
	public void createTCIQDatabasesNew(){
		String createtciqDbRequestBody = "{\n" +
				"    \"id\": \"test_sanath\",\n" +
				"    \"organization_id\": \"spirent\",\n" +
				"    \"name\": \"unique_name\",\n" +
				"    \"datastore\": {\n" +
				"        \"id\": \"default\",\n" +
				"        \"provider\": \"postgres\"\n" +
				"    }\n" +
				"}" ;



		RestAssured.baseURI = "http://10.109.222.123/tciq/databases" ;
		RequestSpecification httpRequest = RestAssured.given();
		httpRequest.header("Content-Type","application/json");
		httpRequest.body(createtciqDbRequestBody) ;

		//Response
		Response response = httpRequest.post();
		System.out.println("Check 1 " +response.statusLine());
		ResponseBody responseBody = response.getBody();
		System.out.println("Check 2 " +responseBody.asString());

		//get values from response
		JsonPath JsonPathEvaluate = response.jsonPath();
		String dbid = JsonPathEvaluate.get("id") ;
		System.out.println("Db id is " +dbid);

	}


	@Test(priority = 2)
	public void deleteMetricsTargets(){


		Response response =
				RestAssured
						.given()
						.contentType(ContentType.JSON)
						.baseUri("http://10.109.222.15/api/v1/metricsclusters/cluster_id_1/metricstargets/exec_id_1")

						//https://restful-booker.herokuapp.com/booking
						.when()
						.delete()
						.then()
						.assertThat()
						.statusCode(204)
						.statusLine("HTTP/1.1 204 NO CONTENT")
						.header("Content-Type", "application/json")
						.extract()
						.response();

		System.out.println("Delete metrics target with execid 1 " +response.statusLine());
		ResponseBody responseBody = response.getBody();
		System.out.println("Delete metrics target response body " +responseBody.asString());


	}

	@Test(priority = 3)
	public void createMetricsTargets(){

		//prepare request body
		/*
		JSONObject global = new JSONObject();
		JSONObject metrics_configs = new JSONObject();

		global.put("scrape_interval", "30s");
		global.put("test_execution_id", "exec_id_1");
		global.put("test_database_id", "a2x2iqq2dvcmroaw");



		metrics_configs.put("job", "cadvisor");
		metrics_configs.put("checkout", "2023-03-30");

		Response response =
		RestAssured
				.given()
					.contentType(ContentType.JSON)
					.body(global.toString())
					.baseUri("https://restful-booker.herokuapp.com/booking")
					//.log().all()
				.when()
					.post()
				.then()
					.assertThat()
					//.log().ifValidationFails()
					.statusCode(200)
					.body("booking.firstname", Matchers.equalTo("api testing"))
					.body("booking.totalprice", Matchers.equalTo(1000))
					.body("booking.bookingdates.checkin", Matchers.equalTo("2023-03-25"))
				.extract()
					.response();

		int bookingId = response.path("bookingid");

		RestAssured
				.given()
					.contentType(ContentType.JSON)
					.pathParam("bookingID", bookingId)
					.baseUri("https://restful-booker.herokuapp.com/booking")
				.when()
					.get("{bookingID}")
				.then()
					.assertThat()
					.statusCode(200)
					.body("firstname", Matchers.equalTo("api testing"))
					.body("lastname", Matchers.equalTo("tutorial"));

		 */
		String metricsTargetRequestBody = "{\n" +
				"   \"global\":{\n" +
				"      \"scrape_interval\":\"30s\",      \n" +
				"      \"test_execution_id\": \"exec_id_1\",\n" +
				"      \"test_database_id\": \"a2x2iqq2dvcmroaw\"\n" +
				"   },\n" +
				"   \"metrics_configs\":[\n" +
				"            {\n" +
				"                \"job\":\"cadvisor\",\n" +
				"                \"node_list\": [\n" +
				"                    \"compute2.ec2.calenglab.spirentcom.com\"\n" +
				"                ]\n" +
				"            },\n" +
				"            {\n" +
				"                \"job\":\"node-exporter\",\n" +
				"                \"pod_list\": [\n" +
				"                    \"10.109.209.35:9153\"\n" +
				"                ]\n" +
				"            }\n" +
				"    ]\n" +
				"}" ;

		Response response =
				RestAssured
						.given()
						.contentType(ContentType.JSON)
						.body(metricsTargetRequestBody)
						.baseUri("http://10.109.222.15/api/v1/metricsclusters/cluster_id_1/metricstargets")
						//.log().all()
						.when()
						.post()
						.then()
						.assertThat()
						//.log().ifValidationFails()
						.statusCode(201)
						.statusLine("HTTP/1.1 201 CREATED")
						//.body("global.test_execution_id", Matchers.equalTo("exec_id_1"))
						//.body("global.metrics_configs[0].job", Matchers.equalTo("cadvisor"))
//						.body("booking.totalprice", Matchers.equalTo(1000))
//						.body("booking.bookingdates.checkin", Matchers.equalTo("2023-03-25"))
						.extract()
						.response();

		System.out.println("Post metrics target with execid 1 " +response.statusLine());
		ResponseBody responseBody = response.getBody();
		System.out.println("Post metrics target response body " +responseBody.asString());
		String bodyAsString = responseBody.asString();

		Assert.assertEquals(bodyAsString.toLowerCase().contains("exec_id_1") /*Expected value*/, true /*Actual Value*/, "Response body contains exec_id_1");








	}



}
